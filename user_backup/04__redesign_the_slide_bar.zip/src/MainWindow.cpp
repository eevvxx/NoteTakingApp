// src/MainWindow.cpp
#include "MainWindow.h" // Include the header file for our main window

// Include necessary Qt headers
#include <QtWidgets> // Includes most common widgets (QLabel, QPushButton, Layouts, etc.)
#include <QStandardItemModel> // For the list view data
#include <QStandardItem> // For items within the model
#include <QDebug> // For printing debug messages
#include <QMessageBox> // For showing warnings

// Constructor
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent) // Call the base class constructor
{
    // Initialize models first (parented to 'this' for auto memory management)
    notebookModel = new QStandardItemModel(this);
    sectionModel = new QStandardItemModel(this);
    pageModel = new QStandardItemModel(this);

    setupUI(); // Create the UI elements
    createActions(); // Create menu/toolbar actions
    createMenus(); // Create the main menu bar
    createStatusBar(); // Create the status bar at the bottom
    loadInitialData(); // Populate models with placeholder data

    // Set window properties
    setWindowTitle(tr("Note Taking App")); // Use tr() for potential translation
    setMinimumSize(800, 600); // Set a reasonable minimum size
    resize(1100, 800); // Set a default startup size
}

// Destructor
MainWindow::~MainWindow()
{
    // Qt's parent-child mechanism handles deleting child widgets and models
}

// --- Setup the main UI structure ---
void MainWindow::setupUI()
{
    // --- Create Panel Widgets (Containers) ---
    notebookPanel = new QWidget();
    notebookPanel->setObjectName("notebookPanel"); // For QSS styling
    sectionPanel = new QWidget();
    sectionPanel->setObjectName("sectionPanel");
    pagePanel = new QWidget();
    pagePanel->setObjectName("pagePanel");

    // --- Create Headers for each Panel ---
    // Notebook Header
    QWidget *notebookHeader = new QWidget();
    notebookHeader->setObjectName("panelHeader");
    QHBoxLayout *notebookHeaderLayout = new QHBoxLayout(notebookHeader);
    notebookHeaderLayout->setContentsMargins(5, 3, 5, 3); // Small margins
    QLabel *notebookLabel = new QLabel(tr("Notebooks"));
    QToolButton *addNotebookButton = new QToolButton();
    addNotebookButton->setObjectName("addButton"); // For QSS
    addNotebookButton->setIcon(style()->standardIcon(QStyle::SP_FileDialogNewFolder)); // Folder icon
    addNotebookButton->setToolTip(tr("Add Notebook"));
    notebookHeaderLayout->addWidget(notebookLabel);
    notebookHeaderLayout->addStretch(); // Push button to the right
    notebookHeaderLayout->addWidget(addNotebookButton);

    // Section Header
    QWidget *sectionHeader = new QWidget();
    sectionHeader->setObjectName("panelHeader");
    QHBoxLayout *sectionHeaderLayout = new QHBoxLayout(sectionHeader);
    sectionHeaderLayout->setContentsMargins(5, 3, 5, 3);
    QLabel *sectionLabel = new QLabel(tr("Sections")); // Title will be updated
    sectionLabel->setObjectName("sectionHeaderLabel"); // To find it later
    QToolButton *addSectionButton = new QToolButton();
    addSectionButton->setObjectName("addButton");
    addSectionButton->setIcon(style()->standardIcon(QStyle::SP_FileDialogNewFolder));
    addSectionButton->setToolTip(tr("Add Section"));
    sectionHeaderLayout->addWidget(sectionLabel);
    sectionHeaderLayout->addStretch();
    sectionHeaderLayout->addWidget(addSectionButton);

    // Page Header
    QWidget *pageHeader = new QWidget();
    pageHeader->setObjectName("panelHeader");
    QHBoxLayout *pageHeaderLayout = new QHBoxLayout(pageHeader);
    pageHeaderLayout->setContentsMargins(5, 3, 5, 3);
    QLabel *pageLabel = new QLabel(tr("Pages")); // Title will be updated
    pageLabel->setObjectName("pageHeaderLabel"); // To find it later
    QToolButton *addPageButton = new QToolButton();
    addPageButton->setObjectName("addButton");
    addPageButton->setIcon(style()->standardIcon(QStyle::SP_FileIcon)); // Document icon
    addPageButton->setToolTip(tr("Add Page"));
    pageHeaderLayout->addWidget(pageLabel);
    pageHeaderLayout->addStretch();
    pageHeaderLayout->addWidget(addPageButton);

    // --- Create List Views ---
    notebookListView = new QListView();
    notebookListView->setObjectName("notebookListView"); // For QSS
    notebookListView->setModel(notebookModel); // Assign the model
    notebookListView->setEditTriggers(QAbstractItemView::NoEditTriggers); // Don't allow editing in place

    sectionListView = new QListView();
    sectionListView->setObjectName("sectionListView");
    sectionListView->setModel(sectionModel);
    sectionListView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    pageListView = new QListView();
    pageListView->setObjectName("pageListView");
    pageListView->setModel(pageModel);
    pageListView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // --- Layout Panels (Add Header and List View to each Panel) ---
    // Notebook Panel Layout
    QVBoxLayout *notebookLayout = new QVBoxLayout(notebookPanel);
    notebookLayout->setContentsMargins(0, 0, 0, 0); // No external margins
    notebookLayout->setSpacing(0); // No space between header and list
    notebookLayout->addWidget(notebookHeader);
    notebookLayout->addWidget(notebookListView);

    // Section Panel Layout
    QVBoxLayout *sectionLayout = new QVBoxLayout(sectionPanel);
    sectionLayout->setContentsMargins(0, 0, 0, 0);
    sectionLayout->setSpacing(0);
    sectionLayout->addWidget(sectionHeader);
    sectionLayout->addWidget(sectionListView);

    // Page Panel Layout
    QVBoxLayout *pageLayout = new QVBoxLayout(pagePanel);
    pageLayout->setContentsMargins(0, 0, 0, 0);
    pageLayout->setSpacing(0);
    pageLayout->addWidget(pageHeader);
    pageLayout->addWidget(pageListView);

    // --- Create Editor ---
    noteEditor = new QTextEdit();
    noteEditor->setObjectName("noteEditor"); // For QSS
    noteEditor->setAcceptRichText(true); // Enable rich text features

    // --- Assemble Splitters ---
    // Inner splitter for Sections and Pages
    sectionPageSplitter = new QSplitter(Qt::Horizontal);
    sectionPageSplitter->setObjectName("sectionPageSplitter");
    sectionPageSplitter->addWidget(sectionPanel);
    sectionPageSplitter->addWidget(pagePanel);
    sectionPageSplitter->setStretchFactor(0, 0); // Section panel fixed size initially
    sectionPageSplitter->setStretchFactor(1, 1); // Page panel takes space

    // Middle splitter for Notebooks and the Section/Page group
    panelsSplitter = new QSplitter(Qt::Horizontal);
    panelsSplitter->setObjectName("panelsSplitter");
    panelsSplitter->addWidget(notebookPanel);
    panelsSplitter->addWidget(sectionPageSplitter); // Add the inner splitter
    panelsSplitter->setStretchFactor(0, 0); // Notebook panel fixed size initially
    panelsSplitter->setStretchFactor(1, 1); // Section/Page group takes space

    // Top-level splitter for the entire panel group and the editor
    topLevelSplitter = new QSplitter(Qt::Horizontal);
    topLevelSplitter->setObjectName("topLevelSplitter");
    topLevelSplitter->addWidget(panelsSplitter); // Add the 3-panel group
    topLevelSplitter->addWidget(noteEditor);
    topLevelSplitter->setStretchFactor(0, 0); // Panel group fixed size initially
    topLevelSplitter->setStretchFactor(1, 1); // Editor takes most space

    // Set initial sizes (adjust these proportions as needed)
    topLevelSplitter->setSizes({600, 500}); // Panels group vs Editor width
    panelsSplitter->setSizes({200, 400});   // Notebooks vs Sections/Pages width
    sectionPageSplitter->setSizes({200, 200}); // Sections vs Pages width

    // Set the main layout for the window
    setCentralWidget(topLevelSplitter);

    // --- Connect Signals and Slots ---
    // Connect selection changes in lists to update other lists/editor
    connect(notebookListView->selectionModel(), &QItemSelectionModel::currentChanged, this, &MainWindow::onNotebookSelected);
    connect(sectionListView->selectionModel(), &QItemSelectionModel::currentChanged, this, &MainWindow::onSectionSelected);
    connect(pageListView->selectionModel(), &QItemSelectionModel::currentChanged, this, &MainWindow::onPageSelected);

    // Connect "Add" buttons to their respective slots
    connect(addNotebookButton, &QToolButton::clicked, this, &MainWindow::addNotebook);
    connect(addSectionButton, &QToolButton::clicked, this, &MainWindow::addSection);
    connect(addPageButton, &QToolButton::clicked, this, &MainWindow::addPage);
}

// --- Populate Models with Initial Placeholder Data ---
void MainWindow::loadInitialData()
{
    // Placeholder Notebooks
    QList<QStandardItem *> notebookItems;
    // Using standard icons (might need adjustment based on theme availability)
    notebookItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_DirIcon), "Aspekte B1-B2"));
    notebookItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_DirIcon), "Fouks_B1_B2"));
    notebookItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_DirIcon), "VHK B2"));
    notebookItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_DirIcon), "PC3"));
    notebookModel->invisibleRootItem()->appendRows(notebookItems);

    // Select the first notebook to trigger loading sections (if any)
    if (notebookModel->rowCount() > 0) {
        notebookListView->setCurrentIndex(notebookModel->index(0, 0));
        // The connect() statement ensures onNotebookSelected is called
    }
}

// --- Create Actions (for menus, shortcuts) ---
void MainWindow::createActions()
{
    // Keep only relevant actions
    exitAction = new QAction(tr("E&xit"), this);
    exitAction->setShortcut(QKeySequence::Quit); // Standard Ctrl+Q / Cmd+Q
    exitAction->setStatusTip(tr("Exit the application"));
    connect(exitAction, &QAction::triggered, this, &QWidget::close); // Connect to window's close slot
}

// --- Create Menu Bar ---
void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    // Add Save, Open etc. actions here later
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);
    // Removed View menu as toggle action is gone
}

// --- Create Status Bar ---
void MainWindow::createStatusBar()
{
    statusBar()->showMessage(tr("Ready"));
}

// --- Slot Implementations ---

// Slot called when a different notebook is selected
void MainWindow::onNotebookSelected(const QModelIndex &index)
{
    sectionModel->clear(); // Clear previous sections
    pageModel->clear();    // Clear previous pages
    noteEditor->clear();   // Clear editor

    // Find header labels using findChild (safer than assuming order)
    QLabel* sectionHeaderLabel = findChild<QLabel*>("sectionHeaderLabel");
    QLabel* pageHeaderLabel = findChild<QLabel*>("pageHeaderLabel");

    if (!index.isValid()) {
        // No valid notebook selected, reset headers
        if(sectionHeaderLabel) sectionHeaderLabel->setText(tr("Sections"));
        if(pageHeaderLabel) pageHeaderLabel->setText(tr("Pages"));
        return;
    }

    // Get selected notebook name
    QString notebookName = notebookModel->data(index, Qt::DisplayRole).toString();
    qDebug() << "Notebook selected:" << notebookName;

    // Update header labels
    if(sectionHeaderLabel) sectionHeaderLabel->setText(notebookName);
    if(pageHeaderLabel) pageHeaderLabel->setText(tr("Pages")); // Reset page header

    // --- Placeholder Section Loading ---
    // In a real app, load sections for 'notebookName' from storage (file/db)
    QList<QStandardItem *> sectionItems;
    if (notebookName == "Aspekte B1-B2") {
        sectionItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_DirLinkIcon), "1")); // Different icon?
        sectionItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_DirLinkIcon), "2"));
        sectionItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_DirLinkIcon), "3"));
    } else if (notebookName == "PC3") {
         sectionItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_DirLinkIcon), "Chapter A"));
         sectionItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_DirLinkIcon), "Chapter B"));
    }
    // Add items to the section model
    sectionModel->invisibleRootItem()->appendRows(sectionItems);
    // --- End Placeholder ---

    // Automatically select the first section if sections were loaded
     if (sectionModel->rowCount() > 0) {
        sectionListView->setCurrentIndex(sectionModel->index(0, 0));
        // onSectionSelected will be called automatically
    }
}

// Slot called when a different section is selected
void MainWindow::onSectionSelected(const QModelIndex &index)
{
    pageModel->clear(); // Clear previous pages
    noteEditor->clear(); // Clear editor

    QLabel* pageHeaderLabel = findChild<QLabel*>("pageHeaderLabel");

    if (!index.isValid()) {
        // No valid section selected
        if(pageHeaderLabel) pageHeaderLabel->setText(tr("Pages"));
        return;
    }

    // Get selected section name and current notebook name (from section header)
    QString sectionName = sectionModel->data(index, Qt::DisplayRole).toString();
    QLabel* sectionHeaderLabel = findChild<QLabel*>("sectionHeaderLabel");
    QString currentNotebook = sectionHeaderLabel ? sectionHeaderLabel->text() : "Unknown Notebook";

    qDebug() << "Section selected:" << sectionName << "in notebook" << currentNotebook;

    // Update page header label
    if(pageHeaderLabel) pageHeaderLabel->setText(sectionName);

    // --- Placeholder Page Loading ---
    // In a real app, load pages for 'sectionName' in 'currentNotebook' from storage
    QList<QStandardItem *> pageItems;
     if (currentNotebook == "Aspekte B1-B2" && sectionName == "1") {
        pageItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_FileIcon), "1"));
        pageItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_FileIcon), "Explain"));
    } else if (currentNotebook == "Aspekte B1-B2" && sectionName == "2") {
        pageItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_FileIcon), "2a"));
        pageItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_FileIcon), "2b Notes"));
    } else if (currentNotebook == "PC3" && sectionName == "Chapter A") {
        pageItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_FileIcon), "Intro"));
        pageItems.append(new QStandardItem(style()->standardIcon(QStyle::SP_FileIcon), "Topic 1"));
    }
    // Add items to the page model
    pageModel->invisibleRootItem()->appendRows(pageItems);
    // --- End Placeholder ---

     // Automatically select the first page if pages were loaded
     if (pageModel->rowCount() > 0) {
        pageListView->setCurrentIndex(pageModel->index(0, 0));
        // onPageSelected will be called automatically
    }
}

// Slot called when a different page is selected
void MainWindow::onPageSelected(const QModelIndex &index)
{
    noteEditor->clear(); // Clear previous content

    if (!index.isValid()) return; // No valid page selected

    // Get names for context
    QString pageName = pageModel->data(index, Qt::DisplayRole).toString();
    QLabel* pageHeaderLabel = findChild<QLabel*>("pageHeaderLabel");
    QLabel* sectionHeaderLabel = findChild<QLabel*>("sectionHeaderLabel");
    QString currentSection = pageHeaderLabel ? pageHeaderLabel->text() : "Unknown Section";
    QString currentNotebook = sectionHeaderLabel ? sectionHeaderLabel->text() : "Unknown Notebook";

    qDebug() << "Page selected:" << pageName << "in section" << currentSection << "of notebook" << currentNotebook;

    // --- Placeholder Content Loading ---
    // In a real app, load content for 'pageName' (likely using IDs stored in the model item)
    noteEditor->setPlainText(tr("Content for page '%1' in section '%2' of notebook '%3'.\n\nReplace this with actual loaded content.")
                             .arg(pageName).arg(currentSection).arg(currentNotebook));
    // --- End Placeholder ---
}

// Slot for the "Add Notebook" button
void MainWindow::addNotebook()
{
    qDebug() << "Add Notebook clicked";
    bool ok;
    QString text = QInputDialog::getText(this, tr("Add Notebook"),
                                         tr("Notebook name:"), QLineEdit::Normal,
                                         "", &ok);
    if (ok && !text.isEmpty()) {
        notebookModel->appendRow(new QStandardItem(style()->standardIcon(QStyle::SP_DirIcon), text));
        // Select the newly added notebook
        notebookListView->setCurrentIndex(notebookModel->index(notebookModel->rowCount() - 1, 0));
    }
}

// Slot for the "Add Section" button
void MainWindow::addSection()
{
     QModelIndex currentNotebookIndex = notebookListView->currentIndex();
     if (!currentNotebookIndex.isValid()) {
         QMessageBox::warning(this, tr("Add Section"), tr("Please select a notebook first."));
         return;
     }
     QString currentNotebookName = notebookModel->data(currentNotebookIndex).toString();
     qDebug() << "Add Section clicked for notebook:" << currentNotebookName;

     bool ok;
     QString text = QInputDialog::getText(this, tr("Add Section"),
                                          tr("Section name:"), QLineEdit::Normal,
                                          "", &ok);
     if (ok && !text.isEmpty()) {
        sectionModel->appendRow(new QStandardItem(style()->standardIcon(QStyle::SP_DirLinkIcon), text));
        // Select the newly added section
        sectionListView->setCurrentIndex(sectionModel->index(sectionModel->rowCount() - 1, 0));
     }
}

// Slot for the "Add Page" button
void MainWindow::addPage()
{
    QModelIndex currentSectionIndex = sectionListView->currentIndex();
     if (!currentSectionIndex.isValid()) {
         QMessageBox::warning(this, tr("Add Page"), tr("Please select a section first."));
         return;
     }
     QString currentSectionName = sectionModel->data(currentSectionIndex).toString();
     qDebug() << "Add Page clicked for section:" << currentSectionName;

     bool ok;
     QString text = QInputDialog::getText(this, tr("Add Page"),
                                          tr("Page name:"), QLineEdit::Normal,
                                          "", &ok);
     if (ok && !text.isEmpty()) {
        pageModel->appendRow(new QStandardItem(style()->standardIcon(QStyle::SP_FileIcon), text));
        // Select the newly added page
        pageListView->setCurrentIndex(pageModel->index(pageModel->rowCount() - 1, 0));
     }
}

// Make sure there are no stray characters after this final brace
