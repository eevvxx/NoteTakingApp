// include/MainWindow.h
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QModelIndex>

// Forward declarations
class QWidget;
class QTextEdit;
class QListView;
class QSplitter;
class QStandardItemModel; // <-- Use QStandardItemModel
class QLabel;
class QToolButton;
class QAction;
// Remove CustomSplitter/Handle forward declarations if not used elsewhere

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Slots for handling selections in the new lists
    void onNotebookSelected(const QModelIndex &index);
    void onSectionSelected(const QModelIndex &index);
    void onPageSelected(const QModelIndex &index);

    // Slots for the new "Add" buttons
    void addNotebook();
    void addSection();
    void addPage();

    // Keep old slots if still relevant (handleNewNote might be replaced by addPage)
    // void handleNewNote();
    // void handleNoteSelection(const QModelIndex &index); // Replaced by onPageSelected

private:
    void setupUI();
    void createActions();
    void createMenus();
    // void createToolbars(); // Toolbar might be removed or repurposed
    void createStatusBar();
    void loadInitialData(); // Helper to populate models initially

    // --- New UI Structure ---
    // Splitters
    QSplitter *topLevelSplitter;    // Separates panels from editor
    QSplitter *panelsSplitter;      // Separates Notebooks from Sections/Pages
    QSplitter *sectionPageSplitter; // Separates Sections from Pages

    // Panel Widgets (Containers)
    QWidget *notebookPanel;
    QWidget *sectionPanel;
    QWidget *pagePanel;

    // List Views
    QListView *notebookListView;
    QListView *sectionListView;
    QListView *pageListView;

    // Models
    QStandardItemModel *notebookModel;
    QStandardItemModel *sectionModel;
    QStandardItemModel *pageModel;

    // Editor
    QTextEdit *noteEditor;
    // --- End New UI Structure ---


    // Actions (Keep relevant ones)
    QAction *exitAction;
    // QAction *newNoteAction; // Maybe repurpose or remove
    // QAction *toggleSidebarAction; // Remove

    // Menus
    QMenu *fileMenu;
    // QMenu *viewMenu; // Remove if toggle action is gone
};

#endif // MAINWINDOW_H