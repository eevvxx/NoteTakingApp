// src/MainWindow.cpp
#include "MainWindow.h" // Include the header file

#include <QtWidgets> // Includes most common Qt Widgets

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupUI();
    createActions();
    createMenus();
    // createToolbars(); // Uncomment later if needed
    createStatusBar();

    // Set initial window properties
    setWindowTitle(tr("Note Taking App")); // tr() for translation support
    setMinimumSize(600, 400);
    resize(900, 700); // Set a default size

    // --- Temporary Data ---
    QStringList initialNotes = {"First Note", "Shopping List", "Meeting Ideas"};
    noteListModel->setStringList(initialNotes);
    noteListView->setCurrentIndex(noteListModel->index(0,0)); // Select first note initially
    noteEditor->setPlainText("Content for the first note..."); // Placeholder content
    // --- End Temporary Data ---
}

MainWindow::~MainWindow()
{
    // Qt handles child widget deletion automatically in most cases
}

void MainWindow::setupUI()
{
    // --- Sidebar Setup ---
    sidebarWidget = new QWidget;
    sidebarWidget->setObjectName("sidebar");
    noteListView = new QListView;
    noteListModel = new QStringListModel(this); // Parent 'this' for memory management
    noteListView->setModel(noteListModel);
    noteListView->setEditTriggers(QAbstractItemView::NoEditTriggers); // Don't allow editing titles directly in list

    QPushButton *newNoteButton = new QPushButton(tr("Add New Note"));

    QVBoxLayout *sidebarLayout = new QVBoxLayout(sidebarWidget); // Layout for the sidebar
    sidebarLayout->addWidget(newNoteButton);
    sidebarLayout->addWidget(noteListView);
    sidebarLayout->setContentsMargins(5, 5, 5, 5); // Add some padding

    // --- Editor Setup ---
    noteEditor = new QTextEdit;
    noteEditor->setAcceptRichText(true); // Allow rich text formatting

    // --- Splitter Setup ---
    mainSplitter = new QSplitter(Qt::Horizontal);
    mainSplitter->addWidget(sidebarWidget);
    mainSplitter->addWidget(noteEditor);
    mainSplitter->setStretchFactor(0, 0); // Sidebar doesn't stretch initially
    mainSplitter->setStretchFactor(1, 1); // Editor takes available space
    mainSplitter->setSizes({250, 650}); // Initial sizes for sidebar and editor

    // Set the central widget of the main window
    setCentralWidget(mainSplitter);

    // --- Connect Signals and Slots ---
    connect(newNoteButton, &QPushButton::clicked, this, &MainWindow::handleNewNote);
    connect(noteListView, &QListView::clicked, this, &MainWindow::handleNoteSelection); // Use clicked or activated
}

void MainWindow::createActions()
{
    newNoteAction = new QAction(tr("&New Note"), this);
    newNoteAction->setShortcut(QKeySequence::New);
    newNoteAction->setStatusTip(tr("Create a new note"));
    connect(newNoteAction, &QAction::triggered, this, &MainWindow::handleNewNote);

    exitAction = new QAction(tr("E&xit"), this);
    exitAction->setShortcut(QKeySequence::Quit); // Standard shortcut (Ctrl+Q or Cmd+Q)
    exitAction->setStatusTip(tr("Exit the application"));
    connect(exitAction, &QAction::triggered, this, &QWidget::close); // Close the window
}

void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(newNoteAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);
    // Add more menus (Edit, View, Help) later
}

void MainWindow::createToolbars()
{
    // Example:
    // QToolBar *fileToolBar = addToolBar(tr("File"));
    // fileToolBar->addAction(newNoteAction);
}

void MainWindow::createStatusBar()
{
    statusBar()->showMessage(tr("Ready"));
}

// --- Slot Implementations ---

void MainWindow::handleNewNote()
{
    // Later: Implement logic to create a new note file/db entry
    int newRow = noteListModel->rowCount();
    noteListModel->insertRow(newRow);
    QModelIndex index = noteListModel->index(newRow, 0);
    noteListModel->setData(index, tr("New Note %1").arg(newRow + 1));
    noteListView->setCurrentIndex(index);
    noteEditor->clear();
    noteEditor->setFocus();
    statusBar()->showMessage(tr("Created new note"), 2000); // Message disappears after 2s
}

void MainWindow::handleNoteSelection(const QModelIndex &index)
{
    if (!index.isValid()) return;

    QString selectedTitle = noteListModel->data(index, Qt::DisplayRole).toString();
    // Later: Load actual content based on the selected title/ID
    noteEditor->setPlainText(tr("Content for: %1").arg(selectedTitle));
    statusBar()->showMessage(tr("Selected '%1'").arg(selectedTitle), 2000);
}