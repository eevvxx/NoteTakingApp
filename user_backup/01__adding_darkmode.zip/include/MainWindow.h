// include/MainWindow.h
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow> // Base class for main application windows

// Forward declarations (reduces compile time dependencies)
class QWidget;
class QTextEdit;
class QListView;
class QSplitter;
class QStringListModel;

class MainWindow : public QMainWindow // Inherit from QMainWindow
{
    Q_OBJECT // Macro required for any class that uses Qt's signals and slots

public:
    MainWindow(QWidget *parent = nullptr); // Constructor
    ~MainWindow(); // Destructor

private slots:
    // Slots are functions that can be connected to signals (e.g., button clicks)
    void handleNewNote();
    void handleNoteSelection(const QModelIndex &index);
    // Add more slots later for saving, deleting etc.

private:
    // Private helper functions to set up the UI
    void setupUI();
    void createActions(); // For menu bar/toolbar actions
    void createMenus();   // For the menu bar
    void createToolbars(); // For toolbars (optional)
    void createStatusBar(); // For the status bar

    // UI Widgets
    QSplitter *mainSplitter; // To divide sidebar and editor
    QWidget *sidebarWidget; // Container for sidebar elements
    QListView *noteListView; // List to display note titles
    QTextEdit *noteEditor; // The rich text editor area

    // Data Model for the list view
    QStringListModel *noteListModel;

    // Actions (for menus/toolbars)
    QAction *newNoteAction;
    QAction *exitAction;
    // Add more actions later

    // Menus
    QMenu *fileMenu;
    // Add more menus later
};

#endif // MAINWINDOW_H