// src/MainWindow.cpp
#include "MainWindow.h"

#include <QtWidgets>
#include <QPropertyAnimation> // <-- Include
#include <QEasingCurve>     // <-- Include for smooth animation

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      isSidebarVisible(true), // Initialize state
      sidebarRestoreWidth(250) // Default/initial width
{
    setupUI(); // sidebarRestoreWidth might be updated here if needed
    createActions();
    createMenus();
    createToolbars(); // <-- Call this now
    createStatusBar();

    // --- Animation Setup ---
    sidebarAnimation = new QPropertyAnimation(this); // Parent to main window
    sidebarAnimation->setTargetObject(sidebarWidget); // Animate the sidebar
    sidebarAnimation->setPropertyName("maximumWidth"); // Animate its max width
    sidebarAnimation->setDuration(250); // Animation duration in milliseconds
    sidebarAnimation->setEasingCurve(QEasingCurve::InOutQuad); // Smoother curve

    // Optional: Hide sidebar completely when animation finishes hiding it
    connect(sidebarAnimation, &QPropertyAnimation::finished, this, [this]() {
        if (!isSidebarVisible) { // Only hide if state is hidden
             sidebarWidget->setVisible(false);
        }
    });
    // --- End Animation Setup ---


    setWindowTitle(tr("Note Taking App"));
    setMinimumSize(600, 400);
    resize(900, 700);

    // --- Temporary Data ---
    QStringList initialNotes = {"First Note", "Shopping List", "Meeting Ideas"};
    noteListModel->setStringList(initialNotes);
    if (noteListModel->rowCount() > 0) {
        noteListView->setCurrentIndex(noteListModel->index(0,0));
        handleNoteSelection(noteListModel->index(0,0)); // Load initial content
    }
    // --- End Temporary Data ---
}

MainWindow::~MainWindow()
{
    // Animation object is parented, Qt should handle deletion
}

void MainWindow::setupUI()
{
    // --- Sidebar Setup ---
    sidebarWidget = new QWidget;
    sidebarWidget->setObjectName("sidebar");
    noteListView = new QListView;
    noteListModel = new QStringListModel(this);
    noteListView->setModel(noteListModel);
    noteListView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    QPushButton *newNoteButton = new QPushButton(tr("Add New Note"));

    QVBoxLayout *sidebarLayout = new QVBoxLayout(sidebarWidget);
    sidebarLayout->addWidget(newNoteButton);
    sidebarLayout->addWidget(noteListView);
    sidebarLayout->setContentsMargins(5, 5, 5, 5);

    // --- Editor Setup ---
    noteEditor = new QTextEdit;
    noteEditor->setAcceptRichText(true);

    // --- Splitter Setup ---
    mainSplitter = new QSplitter(Qt::Horizontal);
    mainSplitter->addWidget(sidebarWidget);
    mainSplitter->addWidget(noteEditor);
    mainSplitter->setStretchFactor(0, 0);
    mainSplitter->setStretchFactor(1, 1);
    mainSplitter->setSizes({sidebarRestoreWidth, width() - sidebarRestoreWidth}); // Use restore width

    setCentralWidget(mainSplitter);

    // --- Connect Signals and Slots ---
    connect(newNoteButton, &QPushButton::clicked, this, &MainWindow::handleNewNote);
    connect(noteListView, &QListView::clicked, this, &MainWindow::handleNoteSelection);
}

void MainWindow::createActions()
{
    newNoteAction = new QAction(tr("&New Note"), this);
    newNoteAction->setShortcut(QKeySequence::New);
    newNoteAction->setStatusTip(tr("Create a new note"));
    connect(newNoteAction, &QAction::triggered, this, &MainWindow::handleNewNote);

    exitAction = new QAction(tr("E&xit"), this);
    exitAction->setShortcut(QKeySequence::Quit);
    exitAction->setStatusTip(tr("Exit the application"));
    connect(exitAction, &QAction::triggered, this, &QWidget::close);

    // --- Toggle Sidebar Action ---
    toggleSidebarAction = new QAction(tr("Toggle Sidebar"), this);
    toggleSidebarAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_L)); // Ctrl+L
    toggleSidebarAction->setStatusTip(tr("Show/Hide Sidebar (Ctrl+L)"));
    connect(toggleSidebarAction, &QAction::triggered, this, &MainWindow::toggleSidebar);
    this->addAction(toggleSidebarAction); // Add action to window for shortcut to work globally
    // --- End Toggle Sidebar Action ---
}

void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(newNoteAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);

    // Optional: Add toggle action to a View menu
    QMenu *viewMenu = menuBar()->addMenu(tr("&View"));
    viewMenu->addAction(toggleSidebarAction);
}

// --- Implement createToolbars ---
void MainWindow::createToolbars()
{
    mainToolBar = addToolBar(tr("Main Toolbar"));
    mainToolBar->setObjectName("mainToolBar"); // Good practice for styling/saving state
    mainToolBar->setMovable(false); // Keep it simple for now

    toggleSidebarButton = new QToolButton(this);
    toggleSidebarButton->setToolTip(tr("Toggle Sidebar (Ctrl+L)"));
    toggleSidebarButton->setStatusTip(tr("Show/Hide Sidebar (Ctrl+L)"));
    // Use standard Qt icons
    toggleSidebarButton->setIcon(style()->standardIcon(QStyle::SP_ArrowLeft)); // Initial state: visible, button shows "hide" action
    toggleSidebarButton->setCheckable(false); // We handle state manually
    connect(toggleSidebarButton, &QToolButton::clicked, this, &MainWindow::toggleSidebar);

    mainToolBar->addWidget(toggleSidebarButton);
    // Add other toolbar buttons here later (Save, Bold, Italic etc.)
}
// --- End createToolbars ---

void MainWindow::createStatusBar()
{
    statusBar()->showMessage(tr("Ready"));
}

// --- Implement toggleSidebar Slot ---
void MainWindow::toggleSidebar()
{
    sidebarAnimation->stop(); // Stop any ongoing animation

    if (isSidebarVisible) {
        // --- Hide Sidebar ---
        // Store current width only if it seems reasonable (not already hidden)
        if (sidebarWidget->width() > 10) {
             sidebarRestoreWidth = sidebarWidget->width();
        }
        sidebarAnimation->setStartValue(sidebarRestoreWidth);
        sidebarAnimation->setEndValue(0); // Animate width to 0
        toggleSidebarButton->setIcon(style()->standardIcon(QStyle::SP_ArrowRight)); // Show "show" icon
        isSidebarVisible = false;
        // sidebarWidget->setVisible(false) will be called on animation finish
    } else {
        // --- Show Sidebar ---
        sidebarWidget->setVisible(true); // Make it visible before animating
        sidebarAnimation->setStartValue(0);
        sidebarAnimation->setEndValue(sidebarRestoreWidth); // Restore to previous width
        toggleSidebarButton->setIcon(style()->standardIcon(QStyle::SP_ArrowLeft)); // Show "hide" icon
        isSidebarVisible = true;
    }

    sidebarAnimation->start();
}
// --- End toggleSidebar Slot ---


// --- Slot Implementations ---

void MainWindow::handleNewNote()
{
    // ... (implementation remains the same) ...
    int newRow = noteListModel->rowCount();
    noteListModel->insertRow(newRow);
    QModelIndex index = noteListModel->index(newRow, 0);
    noteListModel->setData(index, tr("New Note %1").arg(newRow + 1));
    noteListView->setCurrentIndex(index);
    noteEditor->clear();
    noteEditor->setFocus();
    statusBar()->showMessage(tr("Created new note"), 2000);
}

void MainWindow::handleNoteSelection(const QModelIndex &index)
{
    // ... (implementation remains the same) ...
    if (!index.isValid()) {
        noteEditor->setPlainText(""); // Clear editor if selection is invalid
        return;
    }
    QString selectedTitle = noteListModel->data(index, Qt::DisplayRole).toString();
    noteEditor->setPlainText(tr("Content for: %1").arg(selectedTitle));
    statusBar()->showMessage(tr("Selected '%1'").arg(selectedTitle), 2000);
}