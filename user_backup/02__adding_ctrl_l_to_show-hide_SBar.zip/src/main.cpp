// src/main.cpp
#include <QApplication>
#include <QFile> // Needed for loading the stylesheet
#include <QTextStream> // Needed for reading the file
#include <QStyleFactory> // Optional: For setting a base style
#include "MainWindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    // Optional: Set a base style like Fusion for better cross-platform consistency
    // before applying QSS. Some QSS rules work better with Fusion.
    app.setStyle(QStyleFactory::create("Fusion"));

    // --- Load and Apply Stylesheet ---
    QFile styleFile(":/styles/stylesheet.qss"); // Use Qt Resource System path (see below)
    // OR use a direct path for testing (less portable):
    // QFile styleFile("stylesheet.qss");

    if (styleFile.open(QFile::ReadOnly | QFile::Text)) {
        QTextStream stream(&styleFile);
        QString styleSheet = stream.readAll();
        app.setStyleSheet(styleSheet);
        styleFile.close();
    } else {
        qWarning("Could not open stylesheet file!");
        // Consider falling back to a default embedded stylesheet string here
    }
    // --- End Stylesheet ---


    QCoreApplication::setOrganizationName("YourCompanyName");
    QCoreApplication::setApplicationName("NoteApp");
    QCoreApplication::setApplicationVersion("0.1");

    MainWindow mainWindow;
    mainWindow.show();

    return app.exec();
}