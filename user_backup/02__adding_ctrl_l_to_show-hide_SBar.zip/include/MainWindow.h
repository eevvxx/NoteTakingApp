// include/MainWindow.h
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QModelIndex> // Include necessary headers directly

// Forward declarations
class QWidget;
class QTextEdit;
class QListView;
class QSplitter;
class QStringListModel;
class QPropertyAnimation; // <-- Add
class QToolButton;        // <-- Add
class QToolBar;           // <-- Add
class QAction;            // <-- Already used, but good practice

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void handleNewNote();
    void handleNoteSelection(const QModelIndex &index);
    void toggleSidebar(); // <-- Add slot for toggling

private:
    void setupUI();
    void createActions();
    void createMenus();
    void createToolbars(); // <-- Ensure this is declared (was commented out before)
    void createStatusBar();

    // UI Widgets
    QSplitter *mainSplitter;
    QWidget *sidebarWidget;
    QListView *noteListView;
    QTextEdit *noteEditor;

    // Data Model
    QStringListModel *noteListModel;

    // Actions
    QAction *newNoteAction;
    QAction *exitAction;
    QAction *toggleSidebarAction; // <-- Add action for shortcut

    // Menus
    QMenu *fileMenu;

    // Toolbars & Controls
    QToolBar *mainToolBar;        // <-- Add toolbar
    QToolButton *toggleSidebarButton; // <-- Add toggle button

    // Animation & State
    QPropertyAnimation *sidebarAnimation; // <-- Add animation object
    bool isSidebarVisible;                // <-- Add state flag
    int sidebarRestoreWidth;              // <-- Add variable to store width
};

#endif // MAINWINDOW_H