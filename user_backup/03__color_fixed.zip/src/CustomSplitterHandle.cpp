#include "CustomSplitterHandle.h"
#include <QHBoxLayout> // Use layout to position the button
#include <QSplitter>
#include <QStyle>
#include <QPaintEvent> // Include if overriding paintEvent

CustomSplitterHandle::CustomSplitterHandle(Qt::Orientation orientation, QSplitter *parent)
    : QSplitterHandle(orientation, parent), currentOrientation(orientation)
{
    // Set the width on the PARENT splitter
    splitter()->setHandleWidth(18); // Adjust width as needed

    // Create the button
    toggleButton = new QToolButton(this);
    toggleButton->setObjectName("handleToggleButton");
    toggleButton->setToolTip(tr("Toggle Sidebar (Ctrl+L)"));
    toggleButton->setCursor(Qt::ArrowCursor);
    toggleButton->setFocusPolicy(Qt::NoFocus);
    toggleButton->setFixedSize(16, 16);
    updateIcon(true);

    connect(toggleButton, &QToolButton::clicked, this, &CustomSplitterHandle::toggleButtonClicked);

    // Initial positioning (will be refined in resizeEvent)
    toggleButton->move(1, (height() - toggleButton->height()) / 2);
}

void CustomSplitterHandle::updateIcon(bool sidebarVisible)
{
    if (sidebarVisible) {
        // Show '-' or left arrow when visible (action is to hide)
        toggleButton->setIcon(style()->standardIcon(QStyle::SP_ToolBarHorizontalExtensionButton)); // Looks like '<' or '-'
        // Or use custom icons later
    } else {
        // Show '+' or right arrow when hidden (action is to show)
        toggleButton->setIcon(style()->standardIcon(QStyle::SP_ToolBarVerticalExtensionButton)); // Looks like '>' or '+'
    }
}

// Reposition the button when the handle is resized (e.g., window resize)
void CustomSplitterHandle::resizeEvent(QResizeEvent* event)
{
    QSplitterHandle::resizeEvent(event); // Call base implementation

    if (currentOrientation == Qt::Horizontal) {
         // Center the button vertically within the handle's width
         toggleButton->move( (width() - toggleButton->width()) / 2 , (height() - toggleButton->height()) / 2 );
    } else {
         // Center the button horizontally within the handle's height
         toggleButton->move( (width() - toggleButton->width()) / 2 , (height() - toggleButton->height()) / 2 );
    }
}

/*
// Optional: Custom painting if needed (e.g., draw background behind button)
void CustomSplitterHandle::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    // Example: Draw a background color
    painter.fillRect(rect(), QColor("#4c5f72")); // Use your desired handle color

    // Note: Base class paintEvent might draw default handle lines,
    // you might need to prevent that or draw your own visuals.
    // QSplitterHandle::paintEvent(event); // Call base or not depending on desired look
}
*/