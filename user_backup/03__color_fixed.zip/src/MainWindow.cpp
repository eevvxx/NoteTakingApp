// src/MainWindow.cpp
#include "MainWindow.h"
#include "CustomSplitter.h"       // <-- Include custom splitter
#include "CustomSplitterHandle.h" // <-- Include custom handle

#include <QtWidgets>
#include <QPropertyAnimation>
#include <QEasingCurve>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      isSidebarVisible(true),
      sidebarRestoreWidth(250)
{
    setupUI(); // Connect handle signal here
    createActions();
    createMenus();
    // createToolbars(); // Remove call if toolbar is empty
    createStatusBar();

    sidebarAnimation = new QPropertyAnimation(this);
    sidebarAnimation->setTargetObject(sidebarWidget);
    sidebarAnimation->setPropertyName("maximumWidth");
    sidebarAnimation->setDuration(250);
    sidebarAnimation->setEasingCurve(QEasingCurve::InOutQuad);

    connect(sidebarAnimation, &QPropertyAnimation::finished, this, [this]() {
        if (!isSidebarVisible) {
             sidebarWidget->setVisible(false);
        }
    });

    // --- Connect the custom handle's button signal ---
    // Get the handle between sidebar (index 0) and editor (index 1) -> handle(1)
    CustomSplitterHandle* handle = mainSplitter->getCustomHandle(1);
    if (handle) {
        connect(handle, &CustomSplitterHandle::toggleButtonClicked, this, &MainWindow::toggleSidebar);
        // Set initial icon on the handle's button
        handle->updateIcon(isSidebarVisible);
    } else {
        qWarning("Could not find custom splitter handle at index 1!");
    }
    // --- End handle connection ---


    setWindowTitle(tr("Note Taking App"));
    setMinimumSize(600, 400);
    resize(900, 700);

    // --- Temporary Data ---
    QStringList initialNotes = {"First Note", "Shopping List", "Meeting Ideas"};
    noteListModel->setStringList(initialNotes);
    if (noteListModel->rowCount() > 0) {
        noteListView->setCurrentIndex(noteListModel->index(0,0));
        handleNoteSelection(noteListModel->index(0,0));
    }
}

MainWindow::~MainWindow() {}

void MainWindow::setupUI()
{
    // --- Sidebar Setup ---
    sidebarWidget = new QWidget;
    sidebarWidget->setObjectName("sidebar");
    // ... (rest of sidebar setup is the same) ...
    noteListView = new QListView;
    noteListModel = new QStringListModel(this);
    noteListView->setModel(noteListModel);
    noteListView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    QPushButton *newNoteButton = new QPushButton(tr("Add New Note"));
    QVBoxLayout *sidebarLayout = new QVBoxLayout(sidebarWidget);
    sidebarLayout->addWidget(newNoteButton);
    sidebarLayout->addWidget(noteListView);
    sidebarLayout->setContentsMargins(5, 5, 5, 5);

    // --- Editor Setup ---
    noteEditor = new QTextEdit;
    noteEditor->setAcceptRichText(true);

    // --- Splitter Setup ---
    mainSplitter = new CustomSplitter(Qt::Horizontal); // <-- Use CustomSplitter
    mainSplitter->addWidget(sidebarWidget);
    mainSplitter->addWidget(noteEditor);
    mainSplitter->setStretchFactor(0, 0);
    mainSplitter->setStretchFactor(1, 1);
    mainSplitter->setSizes({sidebarRestoreWidth, width() - sidebarRestoreWidth});

    setCentralWidget(mainSplitter);

    // --- Connect List View Signal --- (Button connection moved to constructor)
    connect(noteListView, &QListView::clicked, this, &MainWindow::handleNoteSelection);
}

void MainWindow::createActions()
{
    // ... (newNoteAction, exitAction are the same) ...
    newNoteAction = new QAction(tr("&New Note"), this);
    newNoteAction->setShortcut(QKeySequence::New);
    newNoteAction->setStatusTip(tr("Create a new note"));
    connect(newNoteAction, &QAction::triggered, this, &MainWindow::handleNewNote);

    exitAction = new QAction(tr("E&xit"), this);
    exitAction->setShortcut(QKeySequence::Quit);
    exitAction->setStatusTip(tr("Exit the application"));
    connect(exitAction, &QAction::triggered, this, &QWidget::close);

    // --- Toggle Sidebar Action (Keep for shortcut) ---
    toggleSidebarAction = new QAction(tr("Toggle Sidebar"), this);
    toggleSidebarAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_L));
    toggleSidebarAction->setStatusTip(tr("Show/Hide Sidebar (Ctrl+L)"));
    connect(toggleSidebarAction, &QAction::triggered, this, &MainWindow::toggleSidebar);
    this->addAction(toggleSidebarAction);
}

void MainWindow::createMenus()
{
    // ... (File menu is the same) ...
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(newNoteAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);

    // --- View Menu (Keep toggle action here) ---
    QMenu *viewMenu = menuBar()->addMenu(tr("&View"));
    viewMenu->addAction(toggleSidebarAction);
}

// void MainWindow::createToolbars() // <-- Remove this function or clear its contents
// {
//     // Toolbar and button creation removed
// }

void MainWindow::createStatusBar()
{
    statusBar()->showMessage(tr("Ready"));
}

// --- toggleSidebar Slot ---
void MainWindow::toggleSidebar()
{
    sidebarAnimation->stop();
    CustomSplitterHandle* handle = mainSplitter->getCustomHandle(1); // Get handle again

    if (isSidebarVisible) {
        // Hide
        if (sidebarWidget->width() > 10) {
             sidebarRestoreWidth = sidebarWidget->width();
        }
        sidebarAnimation->setStartValue(sidebarRestoreWidth);
        sidebarAnimation->setEndValue(0);
        if (handle) handle->updateIcon(false); // Update handle icon
        isSidebarVisible = false;
    } else {
        // Show
        sidebarWidget->setVisible(true);
        sidebarAnimation->setStartValue(0);
        sidebarAnimation->setEndValue(sidebarRestoreWidth);
        if (handle) handle->updateIcon(true); // Update handle icon
        isSidebarVisible = true;
    }
    sidebarAnimation->start();
}
// --- End toggleSidebar Slot ---


// --- handleNewNote / handleNoteSelection remain the same ---
void MainWindow::handleNewNote()
{
    int newRow = noteListModel->rowCount();
    noteListModel->insertRow(newRow);
    QModelIndex index = noteListModel->index(newRow, 0);
    noteListModel->setData(index, tr("New Note %1").arg(newRow + 1));
    noteListView->setCurrentIndex(index);
    noteEditor->clear();
    noteEditor->setFocus();
    statusBar()->showMessage(tr("Created new note"), 2000);
}

void MainWindow::handleNoteSelection(const QModelIndex &index)
{
    if (!index.isValid()) {
        noteEditor->setPlainText("");
        return;
    }
    QString selectedTitle = noteListModel->data(index, Qt::DisplayRole).toString();
    noteEditor->setPlainText(tr("Content for: %1").arg(selectedTitle));
    statusBar()->showMessage(tr("Selected '%1'").arg(selectedTitle), 2000);
}