#include "CustomSplitter.h"

CustomSplitter::CustomSplitter(Qt::Orientation orientation, QWidget *parent)
    : QSplitter(orientation, parent)
{}

CustomSplitter::CustomSplitter(QWidget *parent) // Default horizontal
    : QSplitter(Qt::Horizontal, parent)
{}

// Override to create our custom handle
QSplitterHandle *CustomSplitter::createHandle()
{
    // Create and return an instance of our custom handle
    // Pass the orientation and this splitter as the parent
    return new CustomSplitterHandle(orientation(), this);
}

// Helper function to safely get the custom handle
CustomSplitterHandle* CustomSplitter::getCustomHandle(int index)
{
    QSplitterHandle* handle = this->handle(index);
    // Use dynamic_cast for safe type checking
    return dynamic_cast<CustomSplitterHandle*>(handle);
}