#ifndef CUSTOMSPLITTER_H
#define CUSTOMSPLITTER_H

#include <QSplitter>
#include "CustomSplitterHandle.h" // Include custom handle header

class CustomSplitter : public QSplitter
{
    Q_OBJECT

public:
    CustomSplitter(Qt::Orientation orientation, QWidget *parent = nullptr);
    CustomSplitter(QWidget *parent = nullptr); // Default horizontal

    // Helper to get the custom handle (assuming only one relevant handle)
    CustomSplitterHandle* getCustomHandle(int index);

protected:
    // Override the factory method
    QSplitterHandle *createHandle() override;
};

#endif // CUSTOMSPLITTER_H