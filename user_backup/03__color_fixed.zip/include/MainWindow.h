// include/MainWindow.h
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QModelIndex>

// Forward declarations
class QWidget;
class QTextEdit;
class QListView;
// class QSplitter; // Remove old forward declaration
class CustomSplitter; // <-- Add forward declaration for custom splitter
class QStringListModel;
class QPropertyAnimation;
// class QToolButton; // Remove toolbar button forward declaration
// class QToolBar; // Remove toolbar forward declaration
class QAction;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void handleNewNote();
    void handleNoteSelection(const QModelIndex &index);
    void toggleSidebar();

private:
    void setupUI();
    void createActions();
    void createMenus();
    // void createToolbars(); // <-- Remove or comment out if not used for anything else
    void createStatusBar();

    // UI Widgets
    CustomSplitter *mainSplitter; // <-- Change type to CustomSplitter
    QWidget *sidebarWidget;
    QListView *noteListView;
    QTextEdit *noteEditor;

    // Data Model
    QStringListModel *noteListModel;

    // Actions
    QAction *newNoteAction;
    QAction *exitAction;
    QAction *toggleSidebarAction; // Keep for shortcut

    // Menus
    QMenu *fileMenu;

    // Toolbars & Controls - REMOVE OLD TOOLBAR BUTTON
    // QToolBar *mainToolBar;
    // QToolButton *toggleSidebarButton;

    // Animation & State
    QPropertyAnimation *sidebarAnimation;
    bool isSidebarVisible;
    int sidebarRestoreWidth;
};

#endif // MAINWINDOW_H