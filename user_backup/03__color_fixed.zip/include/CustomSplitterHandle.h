#ifndef CUSTOMSPLITTERHANDLE_H
#define CUSTOMSPLITTERHANDLE_H

#include <QSplitterHandle>
#include <QToolButton> // Include QToolButton header

class CustomSplitterHandle : public QSplitterHandle
{
    Q_OBJECT // Need Q_OBJECT for signals

public:
    CustomSplitterHandle(Qt::Orientation orientation, QSplitter *parent = nullptr);

    // Method to update the icon based on sidebar state
    void updateIcon(bool sidebarVisible);

signals:
    // Signal emitted when the embedded button is clicked
    void toggleButtonClicked();

protected:
    // Optional: Override paintEvent if needed for custom background, but layout might suffice
    // void paintEvent(QPaintEvent *event) override;
    void resizeEvent(QResizeEvent* event) override; // To reposition button

private:
    QToolButton *toggleButton;
    Qt::Orientation currentOrientation; // Store orientation
};

#endif // CUSTOMSPLITTERHANDLE_H